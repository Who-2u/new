# Trace Analytics — Vite + React

A professional QA analytics dashboard built with Vite, React, and CSS Modules.
Features light/dark theme toggle, live alerts, tester insights, and Trace Bot AI assistant.

## 🚀 Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Start the dev server
npm run dev

# 3. Open in browser
# http://localhost:5173
```

## 📦 Build for Production

```bash
npm run build
npm run preview
```

## 🗂 Project Structure

```
src/
├── components/          # All UI components (each with .jsx + .module.css)
│   ├── Sidebar.jsx
│   ├── Topbar.jsx
│   ├── StatusCards.jsx
│   ├── AlertPanel.jsx
│   ├── TimeTracking.jsx
│   ├── TestingProgress.jsx
│   ├── WeeklyPerformance.jsx
│   ├── TesterInsights.jsx
│   ├── RecentIssues.jsx
│   ├── AlertEmailConfig.jsx
│   ├── TestCaseManagement.jsx
│   └── TraceBot.jsx
├── context/
│   └── ThemeContext.jsx  # Light/Dark theme state + localStorage
├── data/
│   └── mockData.js       # All mock data — replace with API calls
├── pages/
│   └── Dashboard.jsx     # Main dashboard page layout
├── App.jsx
├── App.module.css
├── index.css             # CSS variables for both themes
└── main.jsx
```

## 🎨 Theming

Theme is controlled via `data-theme` attribute on `<html>`.
CSS variables are defined in `src/index.css` for both `dark` and `light`.
The selected theme is persisted to `localStorage` under key `ta-theme`.

## 🔌 Connecting to Real Data

Replace the mock data in `src/data/mockData.js` with API calls.
Each component imports cleanly from `mockData.js`, so swapping to
`fetch`/`axios`/React Query is straightforward.

## 🛠 Tech Stack

- **Vite 5** — lightning-fast dev server
- **React 18** — component architecture
- **CSS Modules** — scoped styles per component
- **Lucide React** — icon library (included, ready to use)
- **No UI framework** — fully custom, lightweight
