// ─── STATUS CARDS ───────────────────────────────────────────
export const statusCards = [
  {
    id: 'test-ready',
    label: 'Test Ready',
    emoji: '🧪',
    value: 23,
    change: '+4',
    changeDir: 'up',
    changeMeta: 'since yesterday',
    color: 'blue',
    cta: 'View Issues',
  },
  {
    id: 'testing',
    label: 'In Testing',
    emoji: '⚙️',
    value: 11,
    change: '-2',
    changeDir: 'down',
    changeMeta: 'since yesterday',
    color: 'green',
    cta: 'Assign Testers',
  },
  {
    id: 'po-approval',
    label: 'PO Approval',
    emoji: '✅',
    value: 8,
    change: '3 waiting >2d',
    changeDir: 'down',
    changeMeta: '',
    color: 'amber',
    cta: 'Escalate',
  },
  {
    id: 'done',
    label: 'Done',
    emoji: '🏁',
    value: 67,
    change: '+12',
    changeDir: 'up',
    changeMeta: 'this week',
    color: 'purple',
    cta: 'View Report',
  },
]

// ─── ALERTS ─────────────────────────────────────────────────
export const alerts = [
  {
    id: 1,
    type: 'danger',
    icon: '🚫',
    title: 'Moved to PO Approval without test case',
    meta: 'PROJ-4821 · Rajan S. · 3 hours ago',
    tag: 'Critical',
    actions: ['⚡ Create Test Case', '↩ Revert Status', '📢 Notify PO'],
  },
  {
    id: 2,
    type: 'danger',
    icon: '⏱️',
    title: 'Issue stuck in Testing > 5 days',
    meta: 'PROJ-4769 · Meena V. · 6 days elapsed',
    tag: 'Overdue',
    actions: ['👤 Reassign', '📋 Review Blockers', '🔔 Escalate'],
  },
  {
    id: 3,
    type: 'warn',
    icon: '⏳',
    title: 'Not picked up for testing within 8 hrs',
    meta: 'PROJ-4902, PROJ-4903 · 2 issues unassigned',
    tag: 'Warning',
    actions: ['👤 Auto-assign', '📊 Check Capacity'],
  },
  {
    id: 4,
    type: 'warn',
    icon: '🔍',
    title: 'Waiting for PO approval > 48 hrs',
    meta: 'PROJ-4811, PROJ-4798 · 2 issues pending',
    tag: 'Delayed',
    actions: ['📧 Send Reminder', '📅 Schedule Review'],
  },
  {
    id: 5,
    type: 'info',
    icon: '📋',
    title: 'Compliance deviation detected',
    meta: '3 issues missing acceptance criteria before merge',
    tag: 'Info',
    actions: ['📝 Update AC', '🚦 Block Merge'],
  },
]

// ─── TESTERS ────────────────────────────────────────────────
export const testers = [
  {
    id: 1,
    initials: 'MV',
    name: 'Meena V.',
    active: 7,
    max: 8,
    pct: 85,
    status: 'overloaded',
    gradient: 'linear-gradient(135deg,#3b82f6,#8b5cf6)',
  },
  {
    id: 2,
    initials: 'RS',
    name: 'Rajan S.',
    active: 4,
    max: 8,
    pct: 50,
    status: 'balanced',
    gradient: 'linear-gradient(135deg,#06d6a0,#3b82f6)',
  },
  {
    id: 3,
    initials: 'AK',
    name: 'Anita K.',
    active: 2,
    max: 8,
    pct: 30,
    status: 'available',
    gradient: 'linear-gradient(135deg,#f59e0b,#ef4444)',
  },
  {
    id: 4,
    initials: 'PR',
    name: 'Priya R.',
    active: 5,
    max: 8,
    pct: 65,
    status: 'balanced',
    gradient: 'linear-gradient(135deg,#8b5cf6,#ec4899)',
  },
]

// ─── WEEKLY BAR DATA ─────────────────────────────────────────
export const weeklyData = [
  { day: 'Mon', received: 55, completed: 42 },
  { day: 'Tue', received: 40, completed: 38 },
  { day: 'Wed', received: 68, completed: 50 },
  { day: 'Thu', received: 48, completed: 55 },
  { day: 'Fri', received: 72, completed: 45 },
]

// ─── RECENT ISSUES ───────────────────────────────────────────
export const recentIssues = [
  {
    key: 'PROJ-4921',
    summary: 'Login page null pointer exception',
    status: 'testing',
    priority: 'high',
    assignee: 'Meena V.',
    actionLabel: 'View →',
    actionStyle: 'accent',
  },
  {
    key: 'PROJ-4902',
    summary: 'Payment flow timeout issue',
    status: 'ready',
    priority: 'high',
    assignee: 'Unassigned ⚠',
    assigneeDanger: true,
    actionLabel: 'Assign →',
    actionStyle: 'accent',
  },
  {
    key: 'PROJ-4821',
    summary: 'Cart item count mismatch',
    status: 'po',
    priority: 'med',
    assignee: 'Rajan S.',
    actionLabel: '⚠ No TC',
    actionStyle: 'danger',
  },
  {
    key: 'PROJ-4811',
    summary: 'Search filter incorrect results',
    status: 'po',
    priority: 'med',
    assignee: 'Anita K.',
    actionLabel: 'Remind →',
    actionStyle: 'accent',
  },
  {
    key: 'PROJ-4798',
    summary: 'Dark mode theme inconsistency',
    status: 'done',
    priority: 'low',
    assignee: 'Priya R.',
    actionLabel: 'View →',
    actionStyle: 'accent',
  },
  {
    key: 'PROJ-4769',
    summary: 'User profile update fails silently',
    status: 'testing',
    priority: 'high',
    assignee: 'Meena V.',
    actionLabel: '⏱ Stuck →',
    actionStyle: 'warn',
  },
]

// ─── TEST CASES ──────────────────────────────────────────────
export const missingTestCases = [
  { key: 'PROJ-4821', title: 'Cart item count mismatch' },
  { key: 'PROJ-4903', title: 'Checkout address validation' },
  { key: 'PROJ-4879', title: 'Report export PDF encoding' },
]

// ─── PIE CHART ───────────────────────────────────────────────
export const progressData = [
  { label: 'Test Ready',  pct: 30, color: '#3b82f6' },
  { label: 'Testing',     pct: 22, color: '#06d6a0' },
  { label: 'PO Approval', pct: 18, color: '#f59e0b' },
  { label: 'Done',        pct: 30, color: '#8b5cf6' },
]

// ─── CHATBOT RESPONSES ───────────────────────────────────────
export const botResponses = {
  stuck:    '🔴 2 issues stuck in Testing:\n• PROJ-4769 — User profile update (Meena V., 6 days)\n• PROJ-4821 — Cart mismatch (Rajan S., 5.2 days)\n\nRecommendation: Reassign or escalate.',
  po:       '🟡 2 issues awaiting PO Approval:\n• PROJ-4811 — Search filter (49h wait)\n• PROJ-4798 — Dark mode (52h wait)\n\nSuggestion: Send escalation email.',
  velocity: '📈 Sprint 47 Velocity: 81%\n• Received: 58 tickets\n• Completed: 47 tickets\n• Trend: ↓3% vs last sprint',
  overload: '⚠️ Meena V. is overloaded (7 active). Anita K. has capacity (2 active). Consider reassigning 2–3 tickets.',
  fallback: "I can help with alerts, stuck issues, team workload, sprint velocity, test coverage, and more. Try asking something specific!",
}
