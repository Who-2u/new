import { weeklyData } from '../data/mockData'
import styles from './WeeklyPerformance.module.css'

const MAX = Math.max(...weeklyData.flatMap(d => [d.received, d.completed]))

export default function WeeklyPerformance() {
  return (
    <div className={styles.card}>
      <div className={styles.header}>
        <div>
          <div className={styles.title}>📈 Weekly Performance</div>
          <div className={styles.subtitle}>Received vs Completed — Sprint 47</div>
        </div>
      </div>
      <div className={styles.body}>
        <div className={styles.velGrid}>
          <div className={styles.velItem}>
            <div className={styles.velNum} style={{ color: 'var(--stat-blue)' }}>58</div>
            <div className={styles.velLbl}>Received</div>
          </div>
          <div className={styles.velItem}>
            <div className={styles.velNum} style={{ color: 'var(--stat-green)' }}>47</div>
            <div className={styles.velLbl}>Completed</div>
          </div>
          <div className={styles.velItem}>
            <div className={styles.velNum} style={{ color: 'var(--warn)' }}>81%</div>
            <div className={styles.velLbl}>Velocity</div>
          </div>
        </div>

        <div className={styles.chart}>
          {weeklyData.map((d, i) => (
            <div key={i} className={styles.barGroup}>
              <div className={styles.bars}>
                <div
                  className={`${styles.bar} ${styles.received}`}
                  style={{ height: `${(d.received / MAX) * 90}px` }}
                />
                <div
                  className={`${styles.bar} ${styles.completed}`}
                  style={{ height: `${(d.completed / MAX) * 90}px` }}
                />
              </div>
              <div className={styles.day}>{d.day}</div>
            </div>
          ))}
        </div>

        <div className={styles.legend}>
          <div className={styles.legendItem}>
            <span className={styles.legendDot} style={{ background: 'rgba(59,130,246,0.6)' }} />
            Received
          </div>
          <div className={styles.legendItem}>
            <span className={styles.legendDot} style={{ background: 'rgba(6,214,160,0.65)' }} />
            Completed
          </div>
        </div>

        <div className={styles.actions}>
          <button className={styles.btnGhost}>📊 Trend View</button>
          <button className={styles.btnGhost}>📤 Export CSV</button>
        </div>
      </div>
    </div>
  )
}
