import styles from './TimeTracking.module.css'

const timeData = [
  { label: 'Test Ready',  pct: 55, color: '#3b82f6', val: '1.4d',      danger: false },
  { label: 'Testing',     pct: 90, color: '#ef4444', val: '3.8d ⚠',   danger: true  },
  { label: 'PO Approval', pct: 70, color: '#f59e0b', val: '2.2d',      warn:   true  },
  { label: 'Done',        pct: 25, color: '#06d6a0', val: '0.3d',      danger: false },
]

export default function TimeTracking() {
  return (
    <div className={styles.card}>
      <div className={styles.header}>
        <div>
          <div className={styles.title}>⏱ Time Tracking</div>
          <div className={styles.subtitle}>Avg. time per status (days)</div>
        </div>
        <button className={styles.btnGhost}>Export</button>
      </div>
      <div className={styles.body}>
        <div className={styles.bars}>
          {timeData.map((row, i) => (
            <div key={i} className={styles.row}>
              <div className={styles.rowLabel}>{row.label}</div>
              <div className={styles.track}>
                <div
                  className={styles.fill}
                  style={{ width: `${row.pct}%`, background: row.color }}
                />
              </div>
              <div
                className={styles.val}
                style={{
                  color: row.danger ? 'var(--danger)' : row.warn ? 'var(--warn)' : 'var(--text)',
                }}
              >
                {row.val}
              </div>
            </div>
          ))}
        </div>

        <div className={styles.alert}>
          <div className={styles.alertTitle}>🔴 Bottleneck: Testing Phase</div>
          <div className={styles.alertDesc}>
            Avg 3.8d exceeds threshold (3d). 4 tickets at risk.
          </div>
          <div className={styles.alertActions}>
            <button className={`${styles.btn} ${styles.btnDanger}`}>👥 Balance Load</button>
            <button className={`${styles.btn} ${styles.btnGhost}`}>📊 Drill Down</button>
          </div>
        </div>
      </div>
    </div>
  )
}
