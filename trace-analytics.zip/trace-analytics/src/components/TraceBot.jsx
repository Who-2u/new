import { useState } from 'react'
import { botResponses } from '../data/mockData'
import styles from './TraceBot.module.css'

const quickPrompts = [
  { label: 'Stuck issues?',  text: 'Which issues are stuck in testing?' },
  { label: 'PO pending?',    text: 'Tickets waiting for PO approval?' },
  { label: 'Velocity?',      text: 'Team velocity this week?' },
  { label: 'Overloaded?',    text: 'Who is overloaded?' },
]

function getResponse(text) {
  const t = text.toLowerCase()
  if (t.includes('stuck') || t.includes('testing')) return botResponses.stuck
  if (t.includes('po') || t.includes('approval') || t.includes('waiting')) return botResponses.po
  if (t.includes('velocity') || t.includes('performance') || t.includes('week')) return botResponses.velocity
  if (t.includes('overload') || t.includes('capacity') || t.includes('load')) return botResponses.overload
  return botResponses.fallback
}

export default function TraceBot() {
  const [open, setOpen] = useState(false)
  const [messages, setMessages] = useState([
    { type: 'bot', text: "👋 Hi! I'm Trace Bot. Ask me anything about your workflow, alerts, or team metrics." },
  ])
  const [input, setInput] = useState('')

  const addMessage = (text, type) => {
    setMessages(prev => [...prev, { type, text }])
  }

  const send = (text) => {
    if (!text.trim()) return
    addMessage(text, 'user')
    setInput('')
    setTimeout(() => addMessage(getResponse(text), 'bot'), 380)
  }

  return (
    <>
      {/* FAB */}
      <button
        className={styles.fab}
        onClick={() => setOpen(o => !o)}
        title="Trace Bot – AI Assistant"
      >
        🤖
      </button>

      {/* Panel */}
      {open && (
        <div className={styles.panel}>
          <div className={styles.panelHeader}>
            <div className={styles.botIcon}>🤖</div>
            <div style={{ flex: 1 }}>
              <div className={styles.botName}>Trace Bot</div>
              <div className={styles.botStatus}>Online · AI Assistant</div>
            </div>
            <button className={styles.closeBtn} onClick={() => setOpen(false)}>✕</button>
          </div>

          <div className={styles.messages}>
            {messages.map((m, i) => (
              <div key={i} className={`${styles.msg} ${styles[m.type]}`}>
                {m.text}
              </div>
            ))}
          </div>

          <div className={styles.quickPrompts}>
            {quickPrompts.map((q, i) => (
              <button key={i} className={styles.quickBtn} onClick={() => send(q.text)}>
                {q.label}
              </button>
            ))}
          </div>

          <div className={styles.inputRow}>
            <input
              className={styles.input}
              placeholder="Ask about issues, alerts, metrics…"
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && send(input)}
            />
            <button className={styles.sendBtn} onClick={() => send(input)}>➤</button>
          </div>
        </div>
      )}
    </>
  )
}
