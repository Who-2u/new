import { useEffect, useRef } from 'react'
import { statusCards } from '../data/mockData'
import styles from './StatusCards.module.css'

function StatCard({ card }) {
  const valueRef = useRef(null)

  useEffect(() => {
    let n = 0
    const target = card.value
    const step = Math.ceil(target / 30)
    const timer = setInterval(() => {
      n = Math.min(n + step, target)
      if (valueRef.current) valueRef.current.textContent = n
      if (n >= target) clearInterval(timer)
    }, 20)
    return () => clearInterval(timer)
  }, [card.value])

  return (
    <div className={`${styles.card} ${styles[card.color]}`}>
      <div className={styles.label}>
        {card.emoji} {card.label}
      </div>
      <div className={styles.value} ref={valueRef}>
        {card.value}
      </div>
      <div className={styles.meta}>
        <span className={`${styles.change} ${card.changeDir === 'down' ? styles.down : ''}`}>
          {card.change}
        </span>
        {card.changeMeta && <span> {card.changeMeta}</span>}
      </div>
      <div className={styles.action}>
        <button className={`${styles.btn} ${card.color === 'amber' ? styles.btnWarn : styles.btnGhost}`}>
          {card.cta} →
        </button>
      </div>
    </div>
  )
}

export default function StatusCards() {
  return (
    <div className={styles.grid}>
      {statusCards.map(card => (
        <StatCard key={card.id} card={card} />
      ))}
    </div>
  )
}
