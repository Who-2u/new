import { testers } from '../data/mockData'
import styles from './TesterInsights.module.css'

const statusMeta = {
  overloaded: { label: '⚠ Overloaded', color: 'var(--danger)' },
  balanced:   { label: '✓ Balanced',   color: 'var(--accent2)' },
  available:  { label: '↑ Available',  color: 'var(--warn)' },
}

export default function TesterInsights() {
  return (
    <div className={styles.card}>
      <div className={styles.header}>
        <div>
          <div className={styles.title}>👤 Tester Insights</div>
          <div className={styles.subtitle}>Workload &amp; capacity</div>
        </div>
        <button className={styles.btnGhost}>Manage</button>
      </div>
      <div className={styles.body}>
        <div className={styles.list}>
          {testers.map(t => {
            const meta = statusMeta[t.status]
            return (
              <div key={t.id} className={styles.item}>
                <div className={styles.avatar} style={{ background: t.gradient }}>
                  {t.initials}
                </div>
                <div className={styles.info}>
                  <div className={styles.name}>{t.name}</div>
                  <div className={styles.barWrap}>
                    <div className={styles.bar} style={{ width: `${t.pct}%` }} />
                  </div>
                </div>
                <div className={styles.right}>
                  <div className={styles.count} style={{ color: meta.color }}>
                    {t.active} active
                  </div>
                  <div className={styles.statusLabel} style={{ color: meta.color }}>
                    {meta.label}
                  </div>
                </div>
              </div>
            )
          })}
        </div>
        <div className={styles.actions}>
          <button className={`${styles.btn} ${styles.btnSuccess}`}>⚖️ Balance Load</button>
          <button className={`${styles.btn} ${styles.btnGhost}`}>📋 Capacity Plan</button>
        </div>
      </div>
    </div>
  )
}
