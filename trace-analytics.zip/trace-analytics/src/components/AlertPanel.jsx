import { alerts } from '../data/mockData'
import styles from './AlertPanel.module.css'

const tagColors = {
  danger: styles.tagDanger,
  warn:   styles.tagWarn,
  info:   styles.tagInfo,
}

export default function AlertPanel() {
  return (
    <div className={styles.card}>
      <div className={styles.header}>
        <div>
          <div className={styles.title}>⚠️ Risk &amp; Alert Panel</div>
          <div className={styles.subtitle}>Active issues requiring immediate attention</div>
        </div>
        <div className={styles.headerRight}>
          <span className={styles.badgeCount}>7</span>
          <button className={styles.btnGhost}>View All</button>
        </div>
      </div>

      <div className={styles.body}>
        <div className={styles.list}>
          {alerts.map(alert => (
            <div key={alert.id} className={`${styles.alertItem} ${styles[alert.type]}`}>
              <div className={styles.alertIcon}>{alert.icon}</div>
              <div className={styles.alertContent}>
                <div className={styles.alertTitle}>{alert.title}</div>
                <div className={styles.alertMeta}>{alert.meta}</div>
                <div className={styles.alertActions}>
                  {alert.actions.map((a, i) => (
                    <button key={i} className={styles.actionPill}>{a}</button>
                  ))}
                </div>
              </div>
              <span className={`${styles.tag} ${tagColors[alert.type]}`}>
                {alert.tag}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
