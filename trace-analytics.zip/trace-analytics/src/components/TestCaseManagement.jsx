import { missingTestCases } from '../data/mockData'
import styles from './TestCaseManagement.module.css'

export default function TestCaseManagement() {
  return (
    <div className={styles.card}>
      <div className={styles.header}>
        <div>
          <div className={styles.title}>✅ Test Case Management</div>
          <div className={styles.subtitle}>Issues missing test cases</div>
        </div>
        <span className={styles.badge}>{missingTestCases.length}</span>
      </div>
      <div className={styles.body}>
        {missingTestCases.map((tc, i) => (
          <div key={i} className={styles.item}>
            <div className={styles.key}>{tc.key}</div>
            <div className={styles.tcTitle}>{tc.title}</div>
            <span className={styles.noTc}>No TC</span>
            <button className={styles.btnCreate}>+ Create</button>
          </div>
        ))}
        <div className={styles.actions}>
          <button className={styles.btnGhost}>📋 Coverage Report</button>
          <button className={styles.btnSuccess}>⚡ Bulk Create</button>
        </div>
      </div>
    </div>
  )
}
