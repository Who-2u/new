import { useTheme } from '../context/ThemeContext'
import styles from './Topbar.module.css'

export default function Topbar() {
  const { theme, toggle } = useTheme()
  const isDark = theme === 'dark'

  return (
    <header className={styles.topbar}>
      <div className={styles.title}>
        Dashboard{' '}
        <span className={styles.sub}>Last synced 2 min ago</span>
      </div>

      <div className={styles.actions}>
        {/* Live indicator */}
        <div className={styles.liveWrap}>
          <span className={styles.liveDot} />
          Live
        </div>

        {/* Theme toggle */}
        <button className={styles.themeToggle} onClick={toggle} title="Toggle theme">
          <span className={styles.toggleIcon}>{isDark ? '🌙' : '☀️'}</span>
          <div className={`${styles.toggleTrack} ${!isDark ? styles.trackOn : ''}`}>
            <div className={`${styles.toggleKnob} ${!isDark ? styles.knobOn : ''}`} />
          </div>
          <span className={styles.toggleLabel}>{isDark ? 'Dark' : 'Light'}</span>
        </button>

        <button className={styles.btnGhost}>⟳ Refresh</button>
        <button className={styles.btnGhost}>▼ Sprint 47</button>
        <button className={styles.btnPrimary}>+ Create Issue</button>
      </div>
    </header>
  )
}
