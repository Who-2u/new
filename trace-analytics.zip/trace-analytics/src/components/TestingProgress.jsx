import { progressData } from '../data/mockData'
import styles from './TestingProgress.module.css'

// Build conic-gradient string from data
function buildConic(data) {
  let deg = 0
  return data
    .map(d => {
      const start = deg
      deg += d.pct * 3.6
      return `${d.color} ${start}deg ${deg}deg`
    })
    .join(', ')
}

export default function TestingProgress() {
  const conic = buildConic(progressData)

  return (
    <div className={styles.card}>
      <div className={styles.header}>
        <div>
          <div className={styles.title}>◑ Testing Progress</div>
          <div className={styles.subtitle}>Story distribution</div>
        </div>
      </div>
      <div className={styles.body}>
        <div className={styles.pieWrap}>
          <div className={styles.pie} style={{ background: `conic-gradient(${conic})` }}>
            <div className={styles.pieCenter}>
              <div className={styles.pieTotal}>109</div>
              <div className={styles.pieLabel}>Total</div>
            </div>
          </div>
          <div className={styles.legend}>
            {progressData.map((d, i) => (
              <div key={i} className={styles.legendItem}>
                <span className={styles.dot} style={{ background: d.color }} />
                {d.label}
                <span className={styles.pct} style={{ color: d.color }}>{d.pct}%</span>
              </div>
            ))}
          </div>
        </div>
        <div className={styles.actions}>
          <button className={styles.btnGhost}>📄 Full Report</button>
          <button className={styles.btnGhost}>📅 By Sprint</button>
        </div>
      </div>
    </div>
  )
}
