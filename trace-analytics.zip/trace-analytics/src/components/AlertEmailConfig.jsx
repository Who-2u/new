import styles from './AlertEmailConfig.module.css'

export default function AlertEmailConfig() {
  return (
    <div className={styles.card}>
      <div className={styles.header}>
        <div>
          <div className={styles.title}>✉️ Alert Email Config</div>
          <div className={styles.subtitle}>Notification settings</div>
        </div>
        <button className={styles.btnPrimary}>⚙ Configure</button>
      </div>
      <div className={styles.body}>
        <div className={styles.configRow}><span className={styles.label}>Recipients</span><span className={styles.value}>qa-team@co, po-leads@co +3</span></div>
        <div className={styles.configRow}><span className={styles.label}>Frequency</span><span className={styles.value}>Real-time + Daily Digest</span></div>
        <div className={styles.configRow}><span className={styles.label}>Status</span><span className={styles.value} style={{ color: 'var(--accent2)' }}>✓ Active</span></div>

        <div className={styles.delivery}>
          <div className={styles.deliveryItem}>
            <div className={`${styles.deliveryNum} ${styles.ok}`}>247</div>
            <div className={styles.deliveryLbl}>Delivered</div>
          </div>
          <div className={styles.deliveryItem}>
            <div className={`${styles.deliveryNum} ${styles.fail}`}>3</div>
            <div className={styles.deliveryLbl}>Failed</div>
          </div>
          <div className={styles.deliveryItem}>
            <div className={`${styles.deliveryNum} ${styles.pend}`}>8</div>
            <div className={styles.deliveryLbl}>Pending</div>
          </div>
        </div>

        <div className={styles.actions}>
          <button className={styles.btnGhost}>📋 View Log</button>
          <button className={styles.btnDanger}>🔁 Retry Failed</button>
        </div>
      </div>
    </div>
  )
}
