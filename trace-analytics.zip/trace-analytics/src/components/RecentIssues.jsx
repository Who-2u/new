import { recentIssues } from '../data/mockData'
import styles from './RecentIssues.module.css'

const statusLabels = {
  testing: { label: 'Testing',     cls: styles.testing },
  ready:   { label: 'Test Ready',  cls: styles.ready   },
  po:      { label: 'PO Approval', cls: styles.po      },
  done:    { label: 'Done',        cls: styles.done    },
}

export default function RecentIssues() {
  return (
    <div className={styles.card}>
      <div className={styles.header}>
        <div>
          <div className={styles.title}>📋 Recent Issues</div>
          <div className={styles.subtitle}>Latest activity — 6 of 142</div>
        </div>
        <div className={styles.headerActions}>
          <button className={styles.btnGhost}>🔍 Filter</button>
          <button className={styles.btnPrimary}>View All →</button>
        </div>
      </div>
      <div className={styles.tableWrap}>
        <table className={styles.table}>
          <thead>
            <tr>
              <th>Key</th>
              <th>Summary</th>
              <th>Status</th>
              <th>Priority</th>
              <th>Assignee</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {recentIssues.map((issue, i) => {
              const st = statusLabels[issue.status]
              return (
                <tr key={i}>
                  <td><span className={styles.issueKey}>{issue.key}</span></td>
                  <td className={styles.summary}>{issue.summary}</td>
                  <td>
                    <span className={`${styles.pill} ${st.cls}`}>
                      <span className={styles.dot} />
                      {st.label}
                    </span>
                  </td>
                  <td>
                    <span className={`${styles.priority} ${styles[issue.priority]}`}>
                      {issue.priority === 'high' ? 'High' : issue.priority === 'med' ? 'Med' : 'Low'}
                    </span>
                  </td>
                  <td
                    style={{
                      color: issue.assigneeDanger ? 'var(--danger)' : 'var(--text2)',
                      fontSize: '12px',
                    }}
                  >
                    {issue.assignee}
                  </td>
                  <td>
                    <span
                      className={styles.actionLink}
                      style={{
                        color:
                          issue.actionStyle === 'danger' ? 'var(--danger)'
                          : issue.actionStyle === 'warn' ? 'var(--warn)'
                          : 'var(--accent)',
                      }}
                    >
                      {issue.actionLabel}
                    </span>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </div>
  )
}
