import styles from './Sidebar.module.css'

const navItems = [
  { section: 'Overview' },
  { icon: '⬡', label: 'Dashboard', active: true },
  { icon: '◱', label: 'All Issues', badge: '142', badgeType: 'danger' },
  { icon: '⚡', label: 'Alerts', badge: '7', badgeType: 'warn' },
  { section: 'Analytics' },
  { icon: '◷', label: 'Time Tracking' },
  { icon: '◑', label: 'Testing Progress' },
  { icon: '▤', label: 'Weekly Performance' },
  { icon: '◓', label: 'Tester Insights' },
  { section: 'Management' },
  { icon: '✓', label: 'Test Cases' },
  { icon: '✉', label: 'Alert Config' },
  { icon: '⚙', label: 'Settings' },
]

export default function Sidebar() {
  return (
    <aside className={styles.sidebar}>
      {/* Logo */}
      <div className={styles.logo}>
        <div className={styles.logoIcon}>TA</div>
        <div>
          <div className={styles.logoText}>
            Trace <span>Analytics</span>
          </div>
          <div className={styles.logoSub}>QA Intelligence Hub</div>
        </div>
      </div>

      {/* Nav */}
      <nav className={styles.nav}>
        {navItems.map((item, i) => {
          if (item.section) {
            return (
              <div key={i} className={styles.navSection}>
                {item.section}
              </div>
            )
          }
          return (
            <div
              key={i}
              className={`${styles.navItem} ${item.active ? styles.active : ''}`}
            >
              <span className={styles.icon}>{item.icon}</span>
              {item.label}
              {item.badge && (
                <span
                  className={`${styles.navBadge} ${
                    item.badgeType === 'warn' ? styles.warn : ''
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </div>
          )
        })}
      </nav>

      {/* User */}
      <div className={styles.sidebarBottom}>
        <div className={styles.userCard}>
          <div className={styles.avatar}>SR</div>
          <div className={styles.userInfo}>
            <div className={styles.userName}>Sarah R.</div>
            <div className={styles.userRole}>QA Lead</div>
          </div>
        </div>
      </div>
    </aside>
  )
}
