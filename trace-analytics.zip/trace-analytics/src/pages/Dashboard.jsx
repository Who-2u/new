import StatusCards from '../components/StatusCards'
import AlertPanel from '../components/AlertPanel'
import TimeTracking from '../components/TimeTracking'
import TestingProgress from '../components/TestingProgress'
import WeeklyPerformance from '../components/WeeklyPerformance'
import TesterInsights from '../components/TesterInsights'
import RecentIssues from '../components/RecentIssues'
import AlertEmailConfig from '../components/AlertEmailConfig'
import TestCaseManagement from '../components/TestCaseManagement'
import styles from './Dashboard.module.css'

export default function Dashboard() {
  return (
    <div className={styles.content}>
      {/* Row 1 — Status Cards */}
      <StatusCards />

      {/* Row 2 — Alerts + Time Tracking */}
      <div className={styles.row32}>
        <AlertPanel />
        <TimeTracking />
      </div>

      {/* Row 3 — Progress + Weekly + Testers */}
      <div className={styles.row3col}>
        <TestingProgress />
        <WeeklyPerformance />
        <TesterInsights />
      </div>

      {/* Row 4 — Issues Table + Email + Test Cases */}
      <div className={styles.row32}>
        <RecentIssues />
        <div className={styles.rightStack}>
          <AlertEmailConfig />
          <TestCaseManagement />
        </div>
      </div>
    </div>
  )
}
