import { ThemeProvider } from './context/ThemeContext'
import Sidebar from './components/Sidebar'
import Topbar from './components/Topbar'
import Dashboard from './pages/Dashboard'
import TraceBot from './components/TraceBot'
import styles from './App.module.css'

export default function App() {
  return (
    <ThemeProvider>
      <div className={styles.layout}>
        <Sidebar />
        <div className={styles.main}>
          <Topbar />
          <Dashboard />
        </div>
        <TraceBot />
      </div>
    </ThemeProvider>
  )
}
